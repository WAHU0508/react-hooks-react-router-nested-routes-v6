function About() {
    return (
      <>
        <main>
          <h1>This is my about component!</h1>
        </main>
      </>
    );
  };
  
  export default About;